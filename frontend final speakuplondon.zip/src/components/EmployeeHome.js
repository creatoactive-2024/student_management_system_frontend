import React from 'react'

const EmployeeHome = () => {
  return (
    <h1>EmployeeHome</h1>
  )
}

export default EmployeeHome