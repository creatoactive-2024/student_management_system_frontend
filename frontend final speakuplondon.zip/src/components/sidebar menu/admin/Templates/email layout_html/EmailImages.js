import React from 'react'

const EmailImages = () => {
  return (
    <div>
      
    </div>
  )
}

export default EmailImages
