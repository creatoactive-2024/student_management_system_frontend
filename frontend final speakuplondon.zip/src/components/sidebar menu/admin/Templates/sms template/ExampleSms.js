import React from 'react'

const ExampleSms = () => {
  return (
    <div>
      
    </div>
  )
}

export default ExampleSms
