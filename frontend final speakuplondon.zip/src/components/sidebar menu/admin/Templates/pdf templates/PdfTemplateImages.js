import React from 'react'

const PdfTemplateImages = () => {
  return (
    <div>
      
    </div>
  )
}

export default PdfTemplateImages
