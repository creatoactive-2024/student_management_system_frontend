import React from 'react'

const ExternalApp = () => {
  return (
    <div>
      External App
    </div>
  )
}

export default ExternalApp
