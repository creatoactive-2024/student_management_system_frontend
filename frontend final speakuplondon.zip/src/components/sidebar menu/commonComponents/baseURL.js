// src/config.js
// const baseURL = "http://179.61.188.81:5005"; 
// const baseURL = "https://globaltourmanager.com/public_html/stagging1_SMS_backend:5007"; 

const baseURL = "http://localhost:5005"; 

// const baseURL = "https://globaltourmanager.com:5005"; 


//imp below

//for staging
// const baseURL = "https://globaltourmanager.com/backend"; 

//for live
// const baseURL = "http://194.76.26.223/api"





export default baseURL;
