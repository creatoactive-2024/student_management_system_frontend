import React from 'react'

const Student = () => {
  return (
    <div>
      
    </div>
  )
}

export default Student
