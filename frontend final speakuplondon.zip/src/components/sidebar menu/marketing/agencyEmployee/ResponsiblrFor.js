import React from 'react'

const ResponsiblrFor = () => {
  return (
    <div>
      
    </div>
  )
}

export default ResponsiblrFor
