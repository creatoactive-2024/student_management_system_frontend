import React from 'react'

const Placeholder = () => {
  return (
    <div>
      
    </div>
  )
}

export default Placeholder
